rm -f *.txt
rm -f *.map
rm -f *.hdr
rm -f *.bil
rm -f *.stx
rm -rf allStatisticsResults
