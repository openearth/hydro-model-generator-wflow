__all__ = [
    "__version__", "__author__", "__uri__", "__license__", "__copyright__"
]

__version__ = "4.2.0"
__author__ = "PCRaster Research and Development Team"
__uri__ = "http://www.pcraster.eu"
__license__ = "GPLv3"
__copyright__ = "1990-2018, The PCRaster Research and Development Team"

