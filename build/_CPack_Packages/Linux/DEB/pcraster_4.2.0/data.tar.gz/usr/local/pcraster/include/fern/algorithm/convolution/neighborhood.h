#pragma once
#include "fern/algorithm/convolution/neighborhood/kernel.h"
#include "fern/algorithm/convolution/neighborhood/kernel_traits.h"
#include "fern/algorithm/convolution/neighborhood/square.h"
#include "fern/algorithm/convolution/neighborhood/square_traits.h"
